\$compile\_locking {#variable.compile.locking}
==================

Compile locking avoids concurrent compilation of the same template.

Compile locking is enabled by default. To disable it set
`$compile_locking` to FALSE.
